//3nome='alan';
nome3 = 'alan';
$sobrenome = ' reis ';
_idade = 15;
//!nome = 'teste';
console.log(nome3 + $sobrenome + _idade);
