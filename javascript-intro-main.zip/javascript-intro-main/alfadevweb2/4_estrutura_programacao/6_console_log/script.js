idade = 27;
nome = "Alan";

console.log(`meu nome é ${nome}, tenho ${idade} anos`);
console.log('meu nome é ' + nome +', tenho '+ idade + ' anos');