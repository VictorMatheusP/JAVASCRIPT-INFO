idade = 5;

if(idade == 19){
    console.log('Você não pode beber');
}
if(idade >= 18){
    console.log('Você pode dirigir!');
}

usuario = "alan";
senha = 'lala123';
if((usuario == 'alan') && (senha == 'lala123')){
    console.log('Acesso liberado!');
    alert('Bem vindo ' + usuario);
}

console.log(usuario == 'a5lan');