numero = [0,1,2,3,4,5,6];
nome=['joão', 'Marcos','Denicreidsson'];
booleanos=[true,false,true];

console.log(numero[3]);
console.log(numero[0]);
console.log(booleanos[1]);


