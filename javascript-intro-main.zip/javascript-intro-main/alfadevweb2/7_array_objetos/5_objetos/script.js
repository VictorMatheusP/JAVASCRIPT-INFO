cachorro = {
    cor: 'Caramelo',
    patas: 4,
    nome: 'Cavalo',
    latir: function() {
        console.log('miau au');
    }
}
console.log(cachorro.patas);
console.log(cachorro.nome);
console.log(cachorro.cor);
console.log(cachorro.latir);