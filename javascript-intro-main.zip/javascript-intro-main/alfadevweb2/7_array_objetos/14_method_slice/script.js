num = [0,2,3,4,5,6]

console.log(num.slice(4,5));

console.log(num.slice(4,6));

console.log(num.slice(2));

console.log(num.slice(1,-2));



