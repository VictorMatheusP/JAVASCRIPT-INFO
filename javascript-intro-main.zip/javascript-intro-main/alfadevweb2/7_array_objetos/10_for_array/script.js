nomes = ['Juviliano', 'Billysson', 'Denycride'];

for (let i = 0; i <= nomes.length; i++) {
    console.log(nomes[i]);    
}

