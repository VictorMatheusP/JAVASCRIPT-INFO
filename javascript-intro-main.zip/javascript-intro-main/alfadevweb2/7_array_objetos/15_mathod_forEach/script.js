//Intera cada elemento para array

nome = ['Biruleibe', 'Pixuruca', 'Josémaria', 'Mariajosé']

nome.forEach(x => {
    console.log('Bons estudos ' + x);
});