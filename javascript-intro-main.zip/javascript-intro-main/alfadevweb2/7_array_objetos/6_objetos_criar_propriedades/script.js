pessoa = {
    nome: 'Julietsson',
    idade: 12,
    profissao: 'Administrador'
}
console.log(pessoa.nome);

delete pessoa.nome;//deleta
console.log(pessoa.nome);
console.log(pessoa);

pessoa.casado = false;//cria
console.log(pessoa.casado);

console.log(pessoa);
