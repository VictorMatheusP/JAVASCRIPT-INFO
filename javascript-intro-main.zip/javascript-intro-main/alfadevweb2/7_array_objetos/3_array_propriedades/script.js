numero = [1,2,3,4,5,6];
nome=['joão', 'Marcos','Denicreidsson'];
booleanos=[true,false,true];


console.log(nome.length);

estudate = "Denicreidsson"
console.log(estudantes.length);

function teste($0,$1,$2,$3, $valor = ) {
    
}
console.log(teste.length);