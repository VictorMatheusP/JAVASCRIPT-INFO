nomes = ['Juviliano', 'Billysson', 'Denycride'];

elementoRemovido = nomes.pop();

console.log(nomes);


nomes.push('Tião');

console.log(nomes);