//declarando função
function imprimirConsole(){
    //o que faz a função
    console.log("Olá Mundo");
}
//chamando a função
imprimirConsole();
                        //parametro
function imprimirNumero(num){
    console.log("O número é: " + num);
}
imprimirNumero(2);
imprimirNumero(25);
imprimirNumero(202);
