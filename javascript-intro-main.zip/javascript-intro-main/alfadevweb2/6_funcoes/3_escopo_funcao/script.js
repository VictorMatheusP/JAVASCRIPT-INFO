let y = 10;

function num() {
    if (5>2) {
       let y = 100;
        console.log(y);
    }
}
num();
console.log(y);


