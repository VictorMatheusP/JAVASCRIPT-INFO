dobro = (x) => {
    return x * 2;
}
console.log(dobro(2));

triplo = (x) => x * 3;

console.log(triplo(4));