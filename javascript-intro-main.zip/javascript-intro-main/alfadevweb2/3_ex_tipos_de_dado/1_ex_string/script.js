console.log("Aspas duplas");
console.log('Aspas simples');
console.log(`Literals`);

