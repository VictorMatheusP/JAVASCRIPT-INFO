/* 4_exercicio
Armazene a velocidade de um carro em uma variável,
 com o número que  desejar; 
 Faça uma estrutura if/else  que verifica
 se ele está acima   da velocidade;
80 é a velocidade máxima permitida;
Se estiver acima ou abaixo exiba 
mensagens com console.log*/
velocidade = 70;

if(velocidade > 80){
    console.log("Multado!");
}else{
    console.log("Você não foi multado!")
}