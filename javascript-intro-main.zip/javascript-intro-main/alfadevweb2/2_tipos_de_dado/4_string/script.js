console.log("Meu nome é \n Denycreidsson");
console.log('Sou estudante');
console.log(`Isso é um teste`);

console.log(typeof("Meu nome é Denycreidsson"));
console.log(typeof ('Sou estudante'));
console.log(typeof(`Isso é um teste`));