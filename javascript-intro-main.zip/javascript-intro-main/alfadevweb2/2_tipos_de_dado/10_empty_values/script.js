console.log(null);
console.log(undefined);
x='';

console.log(x);
